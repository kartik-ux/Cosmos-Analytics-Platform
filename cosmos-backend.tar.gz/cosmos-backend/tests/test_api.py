"""
COSMOS API Tests
Run: pytest tests/test_api.py -v
"""
import pytest
import io
import csv
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def _create_test_csv() -> bytes:
    """Generate a small CSV file for testing."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["name", "age", "salary", "department", "score"])
    data = [
        ["Alice", 30, 75000, "Engineering", 88],
        ["Bob", 25, 55000, "Marketing", 72],
        ["Charlie", 35, 90000, "Engineering", 95],
        ["Diana", 28, 62000, "Sales", 81],
        ["Eve", 32, 85000, "Engineering", 91],
        ["Frank", 27, 58000, "Marketing", 68],
        ["Grace", 40, 110000, "Management", 97],
        ["Hank", 29, 60000, "Sales", 75],
        ["Ivy", 33, 78000, "Engineering", 89],
        ["Jack", 26, 52000, "Marketing", 65],
        ["Kate", 38, 95000, "Management", 93],
        ["Leo", 31, 72000, "Sales", 82],
        ["Mia", 24, 48000, "Marketing", 60],
        ["Nick", 36, 88000, "Engineering", 90],
        ["Olivia", 29, 65000, "Sales", 78],
    ]
    for row in data:
        writer.writerow(row)
    return output.getvalue().encode()


class TestHealthCheck:
    def test_health(self):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "healthy"

    def test_root(self):
        resp = client.get("/")
        assert resp.status_code == 200


class TestUpload:
    def test_upload_csv(self):
        csv_data = _create_test_csv()
        resp = client.post(
            "/api/upload",
            files={"file": ("test_data.csv", io.BytesIO(csv_data), "text/csv")},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["rows"] == 15
        assert data["columns"] == 5
        assert data["status"] == "analyzed"
        return data["id"]

    def test_upload_invalid_type(self):
        resp = client.post(
            "/api/upload",
            files={"file": ("test.txt", io.BytesIO(b"hello"), "text/plain")},
        )
        assert resp.status_code == 400

    def test_list_datasets(self):
        resp = client.get("/api/datasets")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    def test_get_dataset_detail(self):
        # Upload first
        csv_data = _create_test_csv()
        upload_resp = client.post(
            "/api/upload",
            files={"file": ("detail_test.csv", io.BytesIO(csv_data), "text/csv")},
        )
        dataset_id = upload_resp.json()["id"]

        resp = client.get(f"/api/datasets/{dataset_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert "column_meta" in data
        assert "preview" in data
        assert len(data["column_meta"]) == 5

    def test_delete_dataset(self):
        csv_data = _create_test_csv()
        upload_resp = client.post(
            "/api/upload",
            files={"file": ("delete_test.csv", io.BytesIO(csv_data), "text/csv")},
        )
        dataset_id = upload_resp.json()["id"]

        resp = client.delete(f"/api/datasets/{dataset_id}")
        assert resp.status_code == 200

        resp2 = client.get(f"/api/datasets/{dataset_id}")
        assert resp2.status_code == 404


class TestAnalysis:
    @pytest.fixture(autouse=True)
    def setup(self):
        csv_data = _create_test_csv()
        resp = client.post(
            "/api/upload",
            files={"file": ("analysis_test.csv", io.BytesIO(csv_data), "text/csv")},
        )
        self.dataset_id = resp.json()["id"]

    def test_statistics(self):
        resp = client.post(f"/api/analysis/{self.dataset_id}/statistics")
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "summary" in data
        assert "numeric" in data
        assert data["summary"]["total_rows"] == 15

    def test_correlations(self):
        resp = client.post(f"/api/analysis/{self.dataset_id}/correlations")
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "matrix" in data
        assert "top_correlations" in data

    def test_clustering(self):
        resp = client.post(
            f"/api/analysis/{self.dataset_id}/clustering",
            json={"n_clusters": 3},
        )
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "profiles" in data
        assert len(data["profiles"]) == 3
        assert "metrics" in data

    def test_classification(self):
        resp = client.post(
            f"/api/analysis/{self.dataset_id}/predict",
            json={"target_column": "department", "model_type": "classification"},
        )
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "metrics" in data
        assert "feature_importances" in data

    def test_regression(self):
        resp = client.post(
            f"/api/analysis/{self.dataset_id}/predict",
            json={"target_column": "salary", "model_type": "regression"},
        )
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "metrics" in data
        assert "r2_score" in data["metrics"]

    def test_anomaly_detection(self):
        resp = client.post(
            f"/api/analysis/{self.dataset_id}/anomalies",
            json={"contamination": 0.1},
        )
        assert resp.status_code == 200
        data = resp.json()["results"]
        assert "anomaly_count" in data

    def test_get_all_results(self):
        # Run a few analyses first
        client.post(f"/api/analysis/{self.dataset_id}/statistics")
        client.post(f"/api/analysis/{self.dataset_id}/correlations")

        resp = client.get(f"/api/analysis/{self.dataset_id}/results")
        assert resp.status_code == 200
        assert len(resp.json()) >= 2


class TestInsights:
    @pytest.fixture(autouse=True)
    def setup(self):
        csv_data = _create_test_csv()
        resp = client.post(
            "/api/upload",
            files={"file": ("insights_test.csv", io.BytesIO(csv_data), "text/csv")},
        )
        self.dataset_id = resp.json()["id"]

    def test_get_insights(self):
        resp = client.get(f"/api/insights/{self.dataset_id}")
        assert resp.status_code == 200
        data = resp.json()["insights"]
        assert "observations" in data
        assert "conclusion" in data
        assert "next_steps" in data
        assert len(data["observations"]) > 0

    def test_get_recommendations(self):
        resp = client.get(f"/api/insights/{self.dataset_id}/recommendations")
        assert resp.status_code == 200
        data = resp.json()
        assert "recommendations" in data
        assert len(data["recommendations"]) > 0
