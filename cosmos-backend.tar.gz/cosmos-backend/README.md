# COSMOS — AI-Driven Client Data Analytics Platform

## Full-Stack Backend with FastAPI + Scikit-learn + PostgreSQL

### Architecture

```
cosmos-backend/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application entry
│   ├── config.py               # Settings & environment vars
│   ├── database.py             # PostgreSQL connection (SQLAlchemy)
│   ├── models/
│   │   ├── __init__.py
│   │   ├── dataset.py          # Dataset & Column ORM models
│   │   └── analysis.py         # Analysis results ORM models
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── upload.py           # File upload endpoints
│   │   ├── analysis.py         # ML analysis endpoints
│   │   └── insights.py         # AI insights endpoints
│   ├── services/
│   │   ├── __init__.py
│   │   ├── parser.py           # CSV/XLSX/JSON file parsing
│   │   ├── statistics.py       # Statistical computations
│   │   ├── ml_engine.py        # Scikit-learn ML models
│   │   └── ai_insights.py      # AI-powered insight generation
│   └── utils/
│       ├── __init__.py
│       └── helpers.py          # Utility functions
├── migrations/
│   └── create_tables.sql       # PostgreSQL schema
├── tests/
│   └── test_api.py             # API tests
├── requirements.txt
├── docker-compose.yml
├── Dockerfile
├── .env.example
└── README.md
```

### Tech Stack

| Layer | Technology |
|-------|-----------|
| API Framework | FastAPI (async, OpenAPI docs) |
| ML Engine | Scikit-learn, NumPy, Pandas |
| Database | PostgreSQL + SQLAlchemy ORM |
| File Parsing | Pandas, OpenPyXL, python-csv |
| Task Queue | Background tasks (FastAPI) |
| Containerization | Docker + Docker Compose |
| Frontend | COSMOS HTML app (already built) |

---

## Quick Start

### 1. Prerequisites
- Python 3.10+
- PostgreSQL 14+
- pip / virtualenv

### 2. Setup

```bash
# Clone and enter project
cd cosmos-backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy environment config
cp .env.example .env
# Edit .env with your PostgreSQL credentials

# Create database
psql -U postgres -c "CREATE DATABASE cosmos_db;"
psql -U postgres -d cosmos_db -f migrations/create_tables.sql

# Run the server
uvicorn app.main:app --reload --port 8000
```

### 3. Docker Setup (Alternative)

```bash
docker-compose up --build
```

This starts:
- FastAPI server on `http://localhost:8000`
- PostgreSQL on `localhost:5432`

### 4. API Documentation

Once running, visit:
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`

---

## API Endpoints

### Upload
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/upload` | Upload CSV/XLSX/JSON file |
| GET | `/api/datasets` | List all uploaded datasets |
| GET | `/api/datasets/{id}` | Get dataset details + preview |
| DELETE | `/api/datasets/{id}` | Delete a dataset |

### Analysis
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/analysis/{dataset_id}/statistics` | Compute full statistics |
| POST | `/api/analysis/{dataset_id}/correlations` | Compute correlation matrix |
| POST | `/api/analysis/{dataset_id}/clustering` | Run K-Means clustering |
| POST | `/api/analysis/{dataset_id}/predict` | Train prediction model |
| GET | `/api/analysis/{dataset_id}/results` | Get all analysis results |

### Insights
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/insights/{dataset_id}` | Get AI-generated insights |
| GET | `/api/insights/{dataset_id}/recommendations` | Get action recommendations |

---

## ML Models Available

1. **K-Means Clustering** — Customer/data segmentation
2. **Random Forest Classifier** — Classification & churn prediction
3. **Linear Regression** — Value prediction & forecasting
4. **Correlation Analysis** — Feature relationship detection
5. **Anomaly Detection** — Outlier identification (Isolation Forest)

---

## Environment Variables

```env
DATABASE_URL=postgresql://postgres:password@localhost:5432/cosmos_db
SECRET_KEY=your-secret-key-here
MAX_UPLOAD_SIZE_MB=50
CORS_ORIGINS=http://localhost:3000,http://localhost:8080
```

Made with ♥ in Belfast
