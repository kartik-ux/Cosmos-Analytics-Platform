-- COSMOS Database Schema
-- Run: psql -U postgres -d cosmos_db -f migrations/create_tables.sql

CREATE TABLE IF NOT EXISTS datasets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    file_type VARCHAR(10) NOT NULL,
    row_count INTEGER DEFAULT 0,
    column_count INTEGER DEFAULT 0,
    file_size_bytes INTEGER DEFAULT 0,
    uploaded_at TIMESTAMPTZ DEFAULT NOW(),
    status VARCHAR(20) DEFAULT 'uploaded',
    data_preview JSONB
);

CREATE TABLE IF NOT EXISTS column_meta (
    id SERIAL PRIMARY KEY,
    dataset_id INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    data_type VARCHAR(20) NOT NULL,
    unique_count INTEGER DEFAULT 0,
    null_count INTEGER DEFAULT 0,
    min_value DOUBLE PRECISION,
    max_value DOUBLE PRECISION,
    mean_value DOUBLE PRECISION,
    median_value DOUBLE PRECISION,
    std_value DOUBLE PRECISION,
    q1_value DOUBLE PRECISION,
    q3_value DOUBLE PRECISION,
    top_values JSONB
);

CREATE TABLE IF NOT EXISTS analysis_results (
    id SERIAL PRIMARY KEY,
    dataset_id INTEGER NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
    analysis_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'running',
    parameters JSONB,
    results JSONB,
    model_metrics JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_message TEXT
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_column_meta_dataset ON column_meta(dataset_id);
CREATE INDEX IF NOT EXISTS idx_analysis_results_dataset ON analysis_results(dataset_id);
CREATE INDEX IF NOT EXISTS idx_analysis_results_type ON analysis_results(analysis_type);
CREATE INDEX IF NOT EXISTS idx_datasets_status ON datasets(status);
