from sqlalchemy import Column, Integer, String, DateTime, Float, JSON, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base


class Dataset(Base):
    __tablename__ = "datasets"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    original_filename = Column(String(255), nullable=False)
    file_type = Column(String(10), nullable=False)  # csv, xlsx, json
    row_count = Column(Integer, default=0)
    column_count = Column(Integer, default=0)
    file_size_bytes = Column(Integer, default=0)
    uploaded_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(20), default="uploaded")  # uploaded, processing, analyzed, error
    data_preview = Column(JSON, nullable=True)  # First 20 rows as JSON

    # Relationships
    columns_meta = relationship("ColumnMeta", back_populates="dataset", cascade="all, delete-orphan")
    analyses = relationship("AnalysisResult", back_populates="dataset", cascade="all, delete-orphan")


class ColumnMeta(Base):
    __tablename__ = "column_meta"

    id = Column(Integer, primary_key=True, index=True)
    dataset_id = Column(Integer, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    data_type = Column(String(20), nullable=False)  # number, string, date, boolean
    unique_count = Column(Integer, default=0)
    null_count = Column(Integer, default=0)
    min_value = Column(Float, nullable=True)
    max_value = Column(Float, nullable=True)
    mean_value = Column(Float, nullable=True)
    median_value = Column(Float, nullable=True)
    std_value = Column(Float, nullable=True)
    q1_value = Column(Float, nullable=True)
    q3_value = Column(Float, nullable=True)
    top_values = Column(JSON, nullable=True)  # Top 10 frequency values

    dataset = relationship("Dataset", back_populates="columns_meta")
