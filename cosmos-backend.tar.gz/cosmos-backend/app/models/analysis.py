from sqlalchemy import Column, Integer, String, DateTime, Float, JSON, ForeignKey, Text
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base


class AnalysisResult(Base):
    __tablename__ = "analysis_results"

    id = Column(Integer, primary_key=True, index=True)
    dataset_id = Column(Integer, ForeignKey("datasets.id", ondelete="CASCADE"), nullable=False)
    analysis_type = Column(String(50), nullable=False)  # statistics, correlation, clustering, prediction, anomaly
    status = Column(String(20), default="running")  # running, completed, failed
    parameters = Column(JSON, nullable=True)  # Input params (n_clusters, target_col, etc.)
    results = Column(JSON, nullable=True)  # Full results payload
    model_metrics = Column(JSON, nullable=True)  # accuracy, f1, silhouette, etc.
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    error_message = Column(Text, nullable=True)

    dataset = relationship("Dataset", back_populates="analyses")
