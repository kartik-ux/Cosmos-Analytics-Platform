from typing import Dict, Any, List


def generate_insights(stats: Dict[str, Any], corr: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Generate AI-style insights from computed statistics and correlations.
    Returns observations, conclusion, and recommended next steps.
    """
    observations = []
    next_steps = []
    summary = stats.get("summary", {})
    numeric = stats.get("numeric", {})
    categorical = stats.get("categorical", {})

    total_rows = summary.get("total_rows", 0)
    total_cols = summary.get("total_columns", 0)
    completeness = summary.get("completeness", 100)
    total_nulls = summary.get("total_nulls", 0)

    # ── Data Quality ──
    if total_nulls > 0:
        worst_col = max(numeric.keys(), key=lambda c: numeric[c].get("count", 0) - total_rows, default=None)
        observations.append({
            "category": "quality",
            "severity": "warning" if completeness > 90 else "critical",
            "color": "#F59E0B" if completeness > 90 else "#EF4444",
            "title": f"Data Completeness: {completeness}%",
            "text": f"Your dataset has {total_nulls:,} missing values across {total_rows * total_cols:,} cells. "
                    f"{'Overall quality is acceptable but could be improved.' if completeness > 90 else 'Significant gaps detected — cleaning recommended before modeling.'}"
        })
        next_steps.append({
            "title": "Clean Missing Data",
            "text": f"Impute or remove the {total_nulls:,} missing values to improve analysis reliability.",
            "priority": "high" if completeness < 90 else "medium"
        })
    else:
        observations.append({
            "category": "quality",
            "severity": "positive",
            "color": "#22C55E",
            "title": "Perfect Data Completeness: 100%",
            "text": "Zero missing values — excellent data quality for reliable analysis and modeling."
        })

    # ── Distribution Analysis ──
    skewed_cols = []
    high_var_col = None
    high_var_cv = 0

    for col, st in numeric.items():
        if abs(st.get("skewness", 0)) > 1.0:
            skewed_cols.append(col)
        cv = st.get("cv", 0)
        if abs(cv) > high_var_cv:
            high_var_cv = abs(cv)
            high_var_col = col

    if skewed_cols:
        observations.append({
            "category": "distribution",
            "severity": "warning",
            "color": "#F59E0B",
            "title": "Skewed Distributions Detected",
            "text": f"{len(skewed_cols)} column(s) show significant skew: {', '.join(skewed_cols[:3])}. "
                    f"This may affect model performance — consider log or Box-Cox transformations."
        })
        next_steps.append({
            "title": "Normalize Skewed Columns",
            "text": f"Apply transformations to {', '.join(skewed_cols[:3])} for better model accuracy.",
            "priority": "medium"
        })
    else:
        observations.append({
            "category": "distribution",
            "severity": "positive",
            "color": "#22C55E",
            "title": "Well-Balanced Distributions",
            "text": "Numeric columns show relatively symmetric distributions — good foundation for statistical modeling."
        })

    # ── Scale Analysis ──
    if len(numeric) >= 2:
        ranges = {col: st.get("max", 0) - st.get("min", 0) for col, st in numeric.items()}
        max_range = max(ranges.values())
        min_range = min(ranges.values()) if min(ranges.values()) > 0 else 1
        if max_range / min_range > 100:
            observations.append({
                "category": "scale",
                "severity": "critical",
                "color": "#EF4444",
                "title": "Large Scale Differences",
                "text": "Columns have vastly different ranges — normalization or standardization is essential before ML modeling."
            })
            next_steps.append({
                "title": "Standardize Features",
                "text": "Apply StandardScaler or MinMaxScaler before training any ML models.",
                "priority": "high"
            })
        else:
            observations.append({
                "category": "scale",
                "severity": "positive",
                "color": "#3B82F6",
                "title": "Comparable Scales",
                "text": "Numeric columns have similar ranges — minimal preprocessing needed for scale-sensitive algorithms."
            })

    # ── Correlation Insights ──
    if corr and "top_correlations" in corr:
        top = corr["top_correlations"]
        if top:
            strongest = top[0]
            r = abs(strongest["correlation"])
            if r > 0.7:
                observations.append({
                    "category": "correlation",
                    "severity": "critical",
                    "color": "#EF4444",
                    "title": f"Strong Correlation: r={strongest['correlation']:.2f}",
                    "text": f'"{strongest["col1"]}" and "{strongest["col2"]}" are highly correlated. '
                            f"Consider removing one to reduce multicollinearity in predictive models."
                })
            elif r > 0.4:
                observations.append({
                    "category": "correlation",
                    "severity": "warning",
                    "color": "#F59E0B",
                    "title": f"Moderate Correlation: r={strongest['correlation']:.2f}",
                    "text": f'"{strongest["col1"]}" and "{strongest["col2"]}" show moderate relationship — '
                            f"worth investigating for feature engineering."
                })

    # ── Categorical Insights ──
    if categorical:
        most_unique = max(categorical.items(), key=lambda x: x[1].get("unique_count", 0))
        observations.append({
            "category": "categorical",
            "severity": "info",
            "color": "#8B5CF6",
            "title": "Categorical Analysis",
            "text": f"{len(categorical)} categorical column(s) detected. "
                    f'"{most_unique[0]}" has the highest variety with {most_unique[1]["unique_count"]} unique values.'
        })
        next_steps.append({
            "title": "Segment by Categories",
            "text": "Use categorical columns to create meaningful segments and compare metrics across groups.",
            "priority": "medium"
        })

    # ── Conclusion ──
    conclusion = (
        f"Your dataset contains {total_rows:,} records across {total_cols} columns "
        f"({summary.get('numeric_columns', 0)} numeric, {summary.get('categorical_columns', 0)} categorical). "
    )
    if completeness > 95:
        conclusion += "Data quality is strong. "
    else:
        conclusion += "Data quality needs attention before modeling. "

    if len(numeric) >= 2:
        conclusion += "Multiple numeric dimensions make this suitable for regression, clustering, and predictive modeling. "

    conclusion += "Overall, this data has solid analytical potential for driving business insights."

    # ── Default next steps ──
    if len(numeric) >= 2:
        next_steps.append({
            "title": "Run Clustering Analysis",
            "text": f"With {len(numeric)} numeric features, K-Means clustering can reveal natural data segments.",
            "priority": "medium"
        })

    next_steps.append({
        "title": "Build Predictive Model",
        "text": f"Train a classifier or regressor using the {len(numeric)} available numeric features.",
        "priority": "low"
    })

    # Sort by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    next_steps.sort(key=lambda x: priority_order.get(x.get("priority", "low"), 2))

    return {
        "observations": observations,
        "conclusion": conclusion,
        "next_steps": next_steps[:4],
        "data_quality_score": min(100, int(completeness + (10 if not skewed_cols else 0))),
    }
