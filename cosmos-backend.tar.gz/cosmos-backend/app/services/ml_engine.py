import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    silhouette_score, accuracy_score, precision_score, recall_score,
    f1_score, r2_score, mean_squared_error, mean_absolute_error
)


def _prepare_numeric_data(df: pd.DataFrame) -> pd.DataFrame:
    """Select numeric columns, fill NaNs with median, and scale."""
    numeric_df = df.select_dtypes(include=[np.number]).copy()
    numeric_df = numeric_df.fillna(numeric_df.median())
    return numeric_df


def run_kmeans_clustering(df: pd.DataFrame, n_clusters: int = 4) -> Dict[str, Any]:
    """
    Run K-Means clustering on numeric columns.
    Returns cluster labels, centroids, and quality metrics.
    """
    numeric_df = _prepare_numeric_data(df)
    if numeric_df.shape[1] < 2:
        return {"error": "Need at least 2 numeric columns for clustering"}

    # Scale the data
    scaler = StandardScaler()
    scaled = scaler.fit_transform(numeric_df)

    # Find optimal K if not specified (elbow method)
    if n_clusters <= 0:
        inertias = []
        K_range = range(2, min(11, len(df) // 2))
        for k in K_range:
            km = KMeans(n_clusters=k, random_state=42, n_init=10)
            km.fit(scaled)
            inertias.append(km.inertia_)
        # Simple elbow: biggest drop
        diffs = [inertias[i] - inertias[i + 1] for i in range(len(inertias) - 1)]
        n_clusters = list(K_range)[diffs.index(max(diffs)) + 1] if diffs else 3

    # Fit K-Means
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = kmeans.fit_predict(scaled)

    # Metrics
    sil_score = float(silhouette_score(scaled, labels)) if n_clusters > 1 else 0

    # Cluster profiles
    df_clustered = numeric_df.copy()
    df_clustered["cluster"] = labels
    profiles = []
    for c in range(n_clusters):
        cluster_data = df_clustered[df_clustered["cluster"] == c].drop(columns=["cluster"])
        profiles.append({
            "cluster_id": c,
            "size": int((labels == c).sum()),
            "percentage": round(float((labels == c).sum() / len(labels) * 100), 1),
            "centroid": {col: round(float(v), 4) for col, v in zip(numeric_df.columns, kmeans.cluster_centers_[c])},
            "averages": {col: round(float(cluster_data[col].mean()), 4) for col in cluster_data.columns},
        })

    return {
        "n_clusters": n_clusters,
        "labels": labels.tolist(),
        "profiles": profiles,
        "metrics": {
            "silhouette_score": round(sil_score, 4),
            "inertia": round(float(kmeans.inertia_), 4),
        },
        "columns_used": numeric_df.columns.tolist(),
    }


def run_classification(
    df: pd.DataFrame,
    target_column: str,
    test_size: float = 0.2
) -> Dict[str, Any]:
    """
    Train a Random Forest Classifier to predict a target column.
    Returns model metrics and feature importances.
    """
    if target_column not in df.columns:
        return {"error": f"Column '{target_column}' not found"}

    # Prepare features (numeric only)
    feature_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c != target_column]
    if not feature_cols:
        return {"error": "No numeric feature columns available"}

    X = df[feature_cols].fillna(df[feature_cols].median())
    y = df[target_column].copy()

    # Encode target if categorical
    le = None
    if not pd.api.types.is_numeric_dtype(y):
        le = LabelEncoder()
        y = pd.Series(le.fit_transform(y.astype(str)))

    y = y.fillna(y.mode().iloc[0] if not y.mode().empty else 0)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

    # Train
    model = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    # Metrics
    avg = "weighted" if len(y.unique()) > 2 else "binary"
    metrics = {
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "precision": round(float(precision_score(y_test, y_pred, average=avg, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, y_pred, average=avg, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, y_pred, average=avg, zero_division=0)), 4),
    }

    # Feature importances
    importances = sorted(
        [{"feature": col, "importance": round(float(imp), 4)}
         for col, imp in zip(feature_cols, model.feature_importances_)],
        key=lambda x: x["importance"], reverse=True
    )

    # Class distribution
    classes = le.classes_.tolist() if le else sorted(y.unique().tolist())

    return {
        "target_column": target_column,
        "feature_columns": feature_cols,
        "class_labels": classes,
        "metrics": metrics,
        "feature_importances": importances,
        "train_size": len(X_train),
        "test_size": len(X_test),
    }


def run_regression(
    df: pd.DataFrame,
    target_column: str,
    test_size: float = 0.2
) -> Dict[str, Any]:
    """
    Train a Linear Regression model to predict a numeric target.
    """
    if target_column not in df.columns:
        return {"error": f"Column '{target_column}' not found"}

    feature_cols = [c for c in df.select_dtypes(include=[np.number]).columns if c != target_column]
    if not feature_cols:
        return {"error": "No numeric feature columns available"}

    X = df[feature_cols].fillna(df[feature_cols].median())
    y = pd.to_numeric(df[target_column], errors="coerce").fillna(0)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    metrics = {
        "r2_score": round(float(r2_score(y_test, y_pred)), 4),
        "rmse": round(float(np.sqrt(mean_squared_error(y_test, y_pred))), 4),
        "mae": round(float(mean_absolute_error(y_test, y_pred)), 4),
    }

    coefficients = sorted(
        [{"feature": col, "coefficient": round(float(coef), 4)}
         for col, coef in zip(feature_cols, model.coef_)],
        key=lambda x: abs(x["coefficient"]), reverse=True
    )

    return {
        "target_column": target_column,
        "feature_columns": feature_cols,
        "metrics": metrics,
        "coefficients": coefficients,
        "intercept": round(float(model.intercept_), 4),
        "train_size": len(X_train),
        "test_size": len(X_test),
    }


def run_anomaly_detection(df: pd.DataFrame, contamination: float = 0.05) -> Dict[str, Any]:
    """
    Detect anomalies using Isolation Forest.
    """
    numeric_df = _prepare_numeric_data(df)
    if numeric_df.shape[1] < 1:
        return {"error": "Need at least 1 numeric column"}

    scaler = StandardScaler()
    scaled = scaler.fit_transform(numeric_df)

    model = IsolationForest(contamination=contamination, random_state=42)
    predictions = model.fit_predict(scaled)  # 1=normal, -1=anomaly

    anomaly_mask = predictions == -1
    anomaly_count = int(anomaly_mask.sum())
    anomaly_indices = np.where(anomaly_mask)[0].tolist()

    return {
        "total_records": len(df),
        "anomaly_count": anomaly_count,
        "anomaly_percentage": round(anomaly_count / len(df) * 100, 2),
        "anomaly_indices": anomaly_indices[:100],  # First 100
        "contamination_used": contamination,
        "columns_used": numeric_df.columns.tolist(),
    }
