import pandas as pd
import numpy as np
from typing import Dict, Any, List


def compute_column_stats(df: pd.DataFrame, col: str) -> Dict[str, Any]:
    """Compute detailed statistics for a single numeric column."""
    series = pd.to_numeric(df[col], errors="coerce").dropna()
    if series.empty:
        return {}

    return {
        "count": int(len(series)),
        "mean": round(float(series.mean()), 4),
        "median": round(float(series.median()), 4),
        "std": round(float(series.std()), 4),
        "min": round(float(series.min()), 4),
        "max": round(float(series.max()), 4),
        "q1": round(float(series.quantile(0.25)), 4),
        "q3": round(float(series.quantile(0.75)), 4),
        "skewness": round(float(series.skew()), 4),
        "kurtosis": round(float(series.kurtosis()), 4),
        "sum": round(float(series.sum()), 4),
        "variance": round(float(series.var()), 4),
        "iqr": round(float(series.quantile(0.75) - series.quantile(0.25)), 4),
        "cv": round(float(series.std() / series.mean() * 100), 2) if series.mean() != 0 else 0,
    }


def compute_full_statistics(df: pd.DataFrame) -> Dict[str, Any]:
    """Compute statistics for all columns in the dataframe."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()

    result = {
        "summary": {
            "total_rows": len(df),
            "total_columns": len(df.columns),
            "numeric_columns": len(numeric_cols),
            "categorical_columns": len(categorical_cols),
            "total_nulls": int(df.isnull().sum().sum()),
            "completeness": round((1 - df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100, 2),
        },
        "numeric": {},
        "categorical": {},
    }

    # Numeric stats
    for col in numeric_cols:
        result["numeric"][col] = compute_column_stats(df, col)

    # Categorical stats
    for col in categorical_cols:
        series = df[col].dropna()
        freq = series.value_counts().head(10)
        result["categorical"][col] = {
            "unique_count": int(series.nunique()),
            "null_count": int(df[col].isnull().sum()),
            "top_values": [
                {"value": str(v), "count": int(c), "percentage": round(c / len(series) * 100, 2)}
                for v, c in freq.items()
            ],
            "mode": str(series.mode().iloc[0]) if not series.mode().empty else None,
        }

    return result


def compute_histogram(df: pd.DataFrame, col: str, bins: int = 15) -> List[Dict]:
    """Compute histogram data for a numeric column."""
    series = pd.to_numeric(df[col], errors="coerce").dropna()
    if series.empty:
        return []

    counts, edges = np.histogram(series, bins=bins)
    return [
        {"bin_start": round(float(edges[i]), 4), "bin_end": round(float(edges[i + 1]), 4), "count": int(counts[i])}
        for i in range(len(counts))
    ]


def compute_correlation_matrix(df: pd.DataFrame) -> Dict[str, Any]:
    """Compute correlation matrix for all numeric columns."""
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        return {"error": "Need at least 2 numeric columns"}

    corr = numeric_df.corr().round(4)

    # Find strongest correlations
    pairs = []
    cols = corr.columns.tolist()
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            pairs.append({
                "col1": cols[i],
                "col2": cols[j],
                "correlation": float(corr.iloc[i, j]),
                "strength": (
                    "strong" if abs(corr.iloc[i, j]) > 0.7
                    else "moderate" if abs(corr.iloc[i, j]) > 0.4
                    else "weak"
                ),
            })

    pairs.sort(key=lambda x: abs(x["correlation"]), reverse=True)

    return {
        "matrix": {col: {c: float(corr.loc[col, c]) for c in cols} for col in cols},
        "columns": cols,
        "top_correlations": pairs[:10],
    }
