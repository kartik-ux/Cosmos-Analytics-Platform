import pandas as pd
import json
import io
from typing import Tuple
from fastapi import UploadFile


async def parse_file(file: UploadFile) -> Tuple[pd.DataFrame, str]:
    """
    Parse uploaded file into a Pandas DataFrame.
    Returns (dataframe, file_type).
    """
    content = await file.read()
    filename = file.filename.lower()

    if filename.endswith(".csv") or filename.endswith(".tsv"):
        sep = "\t" if filename.endswith(".tsv") else ","
        df = pd.read_csv(io.BytesIO(content), sep=sep)
        return df, "csv"

    elif filename.endswith(".xlsx") or filename.endswith(".xls"):
        df = pd.read_excel(io.BytesIO(content), engine="openpyxl")
        return df, "xlsx"

    elif filename.endswith(".json"):
        data = json.loads(content)
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, dict):
            df = pd.DataFrame([data])
        else:
            raise ValueError("JSON must be an array of objects or a single object")
        return df, "json"

    else:
        raise ValueError(f"Unsupported file type: {filename.split('.')[-1]}")


def infer_column_types(df: pd.DataFrame) -> dict:
    """
    Infer semantic data types for each column.
    Returns dict of {column_name: 'number'|'string'|'date'|'boolean'}.
    """
    types = {}
    for col in df.columns:
        series = df[col].dropna()
        if series.empty:
            types[col] = "string"
            continue

        if pd.api.types.is_bool_dtype(series):
            types[col] = "boolean"
        elif pd.api.types.is_numeric_dtype(series):
            types[col] = "number"
        elif pd.api.types.is_datetime64_any_dtype(series):
            types[col] = "date"
        else:
            # Try to parse as date
            try:
                pd.to_datetime(series.head(20), infer_datetime_format=True)
                types[col] = "date"
            except (ValueError, TypeError):
                types[col] = "string"

    return types


def dataframe_to_preview(df: pd.DataFrame, max_rows: int = 20) -> list:
    """Convert first N rows to JSON-serializable list of dicts."""
    preview = df.head(max_rows).copy()
    # Convert any timestamps to strings
    for col in preview.columns:
        if pd.api.types.is_datetime64_any_dtype(preview[col]):
            preview[col] = preview[col].astype(str)
    return preview.where(preview.notna(), None).to_dict(orient="records")
