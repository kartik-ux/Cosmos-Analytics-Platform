from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.dataset import Dataset
from app.models.analysis import AnalysisResult
from app.services.statistics import compute_full_statistics, compute_correlation_matrix
from app.services.ai_insights import generate_insights
import pandas as pd

router = APIRouter(prefix="/api/insights", tags=["Insights"])


@router.get("/{dataset_id}")
def get_insights(dataset_id: int, db: Session = Depends(get_db)):
    """Generate AI-powered insights for a dataset."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    if not dataset.data_preview:
        raise HTTPException(400, "No data available")

    df = pd.DataFrame(dataset.data_preview)

    # Compute stats and correlations
    stats = compute_full_statistics(df)
    corr = compute_correlation_matrix(df) if len(df.select_dtypes(include="number").columns) >= 2 else None

    # Generate insights
    insights = generate_insights(stats, corr)

    return {
        "dataset_id": dataset_id,
        "dataset_name": dataset.name,
        "insights": insights,
    }


@router.get("/{dataset_id}/recommendations")
def get_recommendations(dataset_id: int, db: Session = Depends(get_db)):
    """Get ML model recommendations based on the dataset characteristics."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    if not dataset.data_preview:
        raise HTTPException(400, "No data available")

    df = pd.DataFrame(dataset.data_preview)
    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    categorical_cols = df.select_dtypes(include=["object", "category"]).columns.tolist()
    n_rows = len(df)

    recommendations = []

    # Always recommend statistics
    recommendations.append({
        "model": "Descriptive Statistics",
        "endpoint": f"/api/analysis/{dataset_id}/statistics",
        "method": "POST",
        "reason": "Compute mean, median, std, quartiles, and distribution analysis for all columns.",
        "confidence": "high",
    })

    # Correlation if 2+ numeric
    if len(numeric_cols) >= 2:
        recommendations.append({
            "model": "Correlation Analysis",
            "endpoint": f"/api/analysis/{dataset_id}/correlations",
            "method": "POST",
            "reason": f"Analyze relationships between {len(numeric_cols)} numeric columns.",
            "confidence": "high",
        })

    # Clustering if 2+ numeric and enough rows
    if len(numeric_cols) >= 2 and n_rows >= 20:
        recommendations.append({
            "model": "K-Means Clustering",
            "endpoint": f"/api/analysis/{dataset_id}/clustering",
            "method": "POST",
            "body": {"n_clusters": min(4, n_rows // 5)},
            "reason": "Discover natural segments and patterns in your data.",
            "confidence": "high" if n_rows >= 100 else "medium",
        })

    # Classification if categorical target exists
    if categorical_cols and len(numeric_cols) >= 2:
        target = categorical_cols[0]
        recommendations.append({
            "model": "Random Forest Classifier",
            "endpoint": f"/api/analysis/{dataset_id}/predict",
            "method": "POST",
            "body": {"target_column": target, "model_type": "classification"},
            "reason": f'Predict "{target}" using {len(numeric_cols)} numeric features.',
            "confidence": "medium",
        })

    # Regression if numeric target available
    if len(numeric_cols) >= 3:
        target = numeric_cols[-1]
        recommendations.append({
            "model": "Linear Regression",
            "endpoint": f"/api/analysis/{dataset_id}/predict",
            "method": "POST",
            "body": {"target_column": target, "model_type": "regression"},
            "reason": f'Predict "{target}" values from other numeric features.',
            "confidence": "medium",
        })

    # Anomaly detection
    if len(numeric_cols) >= 1 and n_rows >= 30:
        recommendations.append({
            "model": "Anomaly Detection",
            "endpoint": f"/api/analysis/{dataset_id}/anomalies",
            "method": "POST",
            "body": {"contamination": 0.05},
            "reason": "Identify unusual records that deviate from normal patterns.",
            "confidence": "medium",
        })

    return {
        "dataset_id": dataset_id,
        "total_recommendations": len(recommendations),
        "recommendations": recommendations,
    }
