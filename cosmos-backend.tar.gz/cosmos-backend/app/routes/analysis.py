from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from pydantic import BaseModel
from typing import Optional
from app.database import get_db
from app.models.dataset import Dataset
from app.models.analysis import AnalysisResult
from app.services.statistics import compute_full_statistics, compute_correlation_matrix, compute_histogram
from app.services.ml_engine import run_kmeans_clustering, run_classification, run_regression, run_anomaly_detection
import pandas as pd
import json

router = APIRouter(prefix="/api/analysis", tags=["Analysis"])


def _load_dataframe(dataset: Dataset) -> pd.DataFrame:
    """Reconstruct DataFrame from stored preview (for demo). 
    In production, store the full file and reload from disk/S3."""
    if not dataset.data_preview:
        raise HTTPException(400, "No data available for this dataset")
    return pd.DataFrame(dataset.data_preview)


class ClusteringParams(BaseModel):
    n_clusters: int = 4

class PredictionParams(BaseModel):
    target_column: str
    model_type: str = "classification"  # classification or regression
    test_size: float = 0.2

class AnomalyParams(BaseModel):
    contamination: float = 0.05


@router.post("/{dataset_id}/statistics")
def compute_statistics(dataset_id: int, db: Session = Depends(get_db)):
    """Compute full descriptive statistics for a dataset."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    df = _load_dataframe(dataset)
    stats = compute_full_statistics(df)

    # Save result
    result = AnalysisResult(
        dataset_id=dataset_id,
        analysis_type="statistics",
        status="completed",
        results=stats,
        completed_at=func.now(),
    )
    db.add(result)
    db.commit()

    return {"analysis_id": result.id, "type": "statistics", "results": stats}


@router.post("/{dataset_id}/correlations")
def compute_correlations(dataset_id: int, db: Session = Depends(get_db)):
    """Compute correlation matrix for numeric columns."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    df = _load_dataframe(dataset)
    corr = compute_correlation_matrix(df)

    if "error" in corr:
        raise HTTPException(400, corr["error"])

    result = AnalysisResult(
        dataset_id=dataset_id,
        analysis_type="correlation",
        status="completed",
        results=corr,
        completed_at=func.now(),
    )
    db.add(result)
    db.commit()

    return {"analysis_id": result.id, "type": "correlation", "results": corr}


@router.post("/{dataset_id}/clustering")
def run_clustering(dataset_id: int, params: ClusteringParams, db: Session = Depends(get_db)):
    """Run K-Means clustering on the dataset."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    df = _load_dataframe(dataset)

    try:
        clustering = run_kmeans_clustering(df, n_clusters=params.n_clusters)
    except Exception as e:
        raise HTTPException(500, f"Clustering failed: {str(e)}")

    if "error" in clustering:
        raise HTTPException(400, clustering["error"])

    result = AnalysisResult(
        dataset_id=dataset_id,
        analysis_type="clustering",
        status="completed",
        parameters={"n_clusters": params.n_clusters},
        results={k: v for k, v in clustering.items() if k != "labels"},
        model_metrics=clustering.get("metrics"),
        completed_at=func.now(),
    )
    db.add(result)
    db.commit()

    return {"analysis_id": result.id, "type": "clustering", "results": clustering}


@router.post("/{dataset_id}/predict")
def run_prediction(dataset_id: int, params: PredictionParams, db: Session = Depends(get_db)):
    """Train a prediction model (classification or regression)."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    df = _load_dataframe(dataset)

    try:
        if params.model_type == "regression":
            prediction = run_regression(df, params.target_column, params.test_size)
        else:
            prediction = run_classification(df, params.target_column, params.test_size)
    except Exception as e:
        raise HTTPException(500, f"Prediction failed: {str(e)}")

    if "error" in prediction:
        raise HTTPException(400, prediction["error"])

    result = AnalysisResult(
        dataset_id=dataset_id,
        analysis_type=params.model_type,
        status="completed",
        parameters=params.dict(),
        results=prediction,
        model_metrics=prediction.get("metrics"),
        completed_at=func.now(),
    )
    db.add(result)
    db.commit()

    return {"analysis_id": result.id, "type": params.model_type, "results": prediction}


@router.post("/{dataset_id}/anomalies")
def detect_anomalies(dataset_id: int, params: AnomalyParams, db: Session = Depends(get_db)):
    """Detect anomalies using Isolation Forest."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    df = _load_dataframe(dataset)

    try:
        anomalies = run_anomaly_detection(df, params.contamination)
    except Exception as e:
        raise HTTPException(500, f"Anomaly detection failed: {str(e)}")

    if "error" in anomalies:
        raise HTTPException(400, anomalies["error"])

    result = AnalysisResult(
        dataset_id=dataset_id,
        analysis_type="anomaly_detection",
        status="completed",
        parameters=params.dict(),
        results=anomalies,
        completed_at=func.now(),
    )
    db.add(result)
    db.commit()

    return {"analysis_id": result.id, "type": "anomaly_detection", "results": anomalies}


@router.get("/{dataset_id}/results")
def get_all_results(dataset_id: int, db: Session = Depends(get_db)):
    """Get all analysis results for a dataset."""
    results = db.query(AnalysisResult).filter(
        AnalysisResult.dataset_id == dataset_id
    ).order_by(AnalysisResult.created_at.desc()).all()

    return [
        {
            "id": r.id,
            "type": r.analysis_type,
            "status": r.status,
            "metrics": r.model_metrics,
            "created_at": r.created_at.isoformat(),
            "completed_at": r.completed_at.isoformat() if r.completed_at else None,
        }
        for r in results
    ]
