from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.dataset import Dataset, ColumnMeta
from app.services.parser import parse_file, infer_column_types, dataframe_to_preview
from app.services.statistics import compute_column_stats
from app.config import settings
import pandas as pd

router = APIRouter(prefix="/api", tags=["Upload"])


@router.post("/upload")
async def upload_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload a CSV, XLSX, or JSON file for analysis."""

    # Validate file size
    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(400, f"File exceeds {settings.MAX_UPLOAD_SIZE_MB}MB limit")
    await file.seek(0)

    # Parse the file
    try:
        df, file_type = await parse_file(file)
    except Exception as e:
        raise HTTPException(400, f"Failed to parse file: {str(e)}")

    if df.empty:
        raise HTTPException(400, "File contains no data")

    # Create dataset record
    dataset = Dataset(
        name=file.filename.rsplit(".", 1)[0],
        original_filename=file.filename,
        file_type=file_type,
        row_count=len(df),
        column_count=len(df.columns),
        file_size_bytes=len(content),
        status="processing",
        data_preview=dataframe_to_preview(df),
    )
    db.add(dataset)
    db.flush()

    # Analyze columns and store metadata
    col_types = infer_column_types(df)
    for col_name in df.columns:
        col_type = col_types.get(col_name, "string")
        meta = ColumnMeta(
            dataset_id=dataset.id,
            name=col_name,
            data_type=col_type,
            unique_count=int(df[col_name].nunique()),
            null_count=int(df[col_name].isnull().sum()),
        )

        # Compute numeric stats
        if col_type == "number":
            stats = compute_column_stats(df, col_name)
            meta.min_value = stats.get("min")
            meta.max_value = stats.get("max")
            meta.mean_value = stats.get("mean")
            meta.median_value = stats.get("median")
            meta.std_value = stats.get("std")
            meta.q1_value = stats.get("q1")
            meta.q3_value = stats.get("q3")

        # Compute top values for categorical
        if col_type == "string":
            freq = df[col_name].value_counts().head(10)
            meta.top_values = [
                {"value": str(v), "count": int(c)} for v, c in freq.items()
            ]

        db.add(meta)

    dataset.status = "analyzed"
    db.commit()
    db.refresh(dataset)

    return {
        "id": dataset.id,
        "name": dataset.name,
        "filename": dataset.original_filename,
        "file_type": dataset.file_type,
        "rows": dataset.row_count,
        "columns": dataset.column_count,
        "status": dataset.status,
        "uploaded_at": dataset.uploaded_at.isoformat(),
    }


@router.get("/datasets")
def list_datasets(db: Session = Depends(get_db)):
    """List all uploaded datasets."""
    datasets = db.query(Dataset).order_by(Dataset.uploaded_at.desc()).all()
    return [
        {
            "id": d.id,
            "name": d.name,
            "filename": d.original_filename,
            "file_type": d.file_type,
            "rows": d.row_count,
            "columns": d.column_count,
            "status": d.status,
            "uploaded_at": d.uploaded_at.isoformat(),
        }
        for d in datasets
    ]


@router.get("/datasets/{dataset_id}")
def get_dataset(dataset_id: int, db: Session = Depends(get_db)):
    """Get dataset details with column metadata and data preview."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")

    return {
        "id": dataset.id,
        "name": dataset.name,
        "filename": dataset.original_filename,
        "file_type": dataset.file_type,
        "rows": dataset.row_count,
        "columns": dataset.column_count,
        "status": dataset.status,
        "uploaded_at": dataset.uploaded_at.isoformat(),
        "preview": dataset.data_preview,
        "column_meta": [
            {
                "name": c.name,
                "type": c.data_type,
                "unique": c.unique_count,
                "nulls": c.null_count,
                "min": c.min_value,
                "max": c.max_value,
                "mean": c.mean_value,
                "median": c.median_value,
                "std": c.std_value,
                "q1": c.q1_value,
                "q3": c.q3_value,
                "top_values": c.top_values,
            }
            for c in dataset.columns_meta
        ],
    }


@router.delete("/datasets/{dataset_id}")
def delete_dataset(dataset_id: int, db: Session = Depends(get_db)):
    """Delete a dataset and all associated analyses."""
    dataset = db.query(Dataset).filter(Dataset.id == dataset_id).first()
    if not dataset:
        raise HTTPException(404, "Dataset not found")
    db.delete(dataset)
    db.commit()
    return {"message": f"Dataset '{dataset.name}' deleted successfully"}
