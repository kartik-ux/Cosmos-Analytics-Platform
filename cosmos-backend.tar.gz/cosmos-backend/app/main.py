from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.config import settings
from app.database import engine, Base
from app.routes import upload, analysis, insights
import os

# Create all database tables
Base.metadata.create_all(bind=engine)

# Initialize FastAPI
app = FastAPI(
    title="COSMOS API",
    description="AI-Driven Client Data Analytics Platform — Backend API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — allow frontend to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes
app.include_router(upload.router)
app.include_router(analysis.router)
app.include_router(insights.router)

# Serve static frontend files
static_dir = os.path.join(os.path.dirname(__file__), "..", "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def root():
    """Serve the COSMOS frontend or show API info."""
    frontend = os.path.join(static_dir, "index.html")
    if os.path.exists(frontend):
        return FileResponse(frontend)
    return {
        "app": "COSMOS",
        "description": "AI-Driven Client Data Analytics Platform",
        "version": "1.0.0",
        "docs": "/docs",
        "endpoints": {
            "upload": "/api/upload",
            "datasets": "/api/datasets",
            "analysis": "/api/analysis/{dataset_id}/statistics",
            "insights": "/api/insights/{dataset_id}",
        },
        "made_with": "♥ in Belfast",
    }


@app.get("/health")
def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "cosmos-api"}
